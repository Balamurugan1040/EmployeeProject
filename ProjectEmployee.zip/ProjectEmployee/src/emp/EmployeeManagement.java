package emp;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeManagement {

	public static void main(String[] args) throws Exception {
		
		 List<Employee> employees = new ArrayList<>();
		
		 EmployeeService empService = new EmployeeService();
		 
		 SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		 Calendar calc = Calendar.getInstance();
		 calc.add(Calendar.YEAR, -25);
		 Date dateVal = calc.getTime();
		 
		 	employees.add(new Employee("Arun", "HR", 60000, "Male", date.parse("2015-5-10"),date.parse("1990-1-1"), "Junior"));
	        employees.add(new Employee("Bala", "IT", 75000, "Male", date.parse("2018-8-15"), date.parse("1995-3-15"), "Mid"));
	        employees.add(new Employee("Manisha", "HR", 55000, "Female", date.parse("2020-1-20"), date.parse("2000-7-20"), "Junior"));
	        employees.add(new Employee("Ajay", "IT", 90000, "Male", date.parse("2012-3-25"), date.parse("1985-12-1"), "Senior"));
	        employees.add(new Employee("Aruna", "Sales", 80000, "Female", date.parse("2016-6-30"), date.parse("1992-5-10"), "Mid"));
	        
	        
	        //1.  For Employee Age Validation
	        empService.validateEmpAge(new Employee("Suman", "HR", 30000, "Male", new Date(), dateVal, "Fresher"));
	        	        
	        //2. Print Department Group wise
	        empService.getCountEmpByDept(employees);
	        
	        //3. Group Employees by Department
	        empService.getGroupEmpByDept(employees);
	        
	        //4. Salary Increment For Any of the Dept
	        empService.getIncrementSalary(employees,"IT",5000);
	        
	        //5. Emploees Prmotion whos working on 8+Years
	        empService.getPromoteEmploees(employees);
	}

	public static List<DepartmentCountContainer> countEmployeesByDepartment(List<Employee> employees) {

		Map<String, Long> departmentCounts = employees.stream()
				.collect(Collectors.groupingBy(Employee::getDepartment, Collectors.counting()));

		return departmentCounts.entrySet().stream()
				.map(entry -> new DepartmentCountContainer(entry.getKey(), entry.getValue()))
				.collect(Collectors.toList());
	}

	public static List<DepartmentGroupContainer> groupEmployeesByDepartment(List<Employee> employees) {
		Map<String, List<Employee>> departmentGroups = employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment));

        return departmentGroups.entrySet().stream()
                .map(entry -> new DepartmentGroupContainer(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
	}

	public static List<Employee> increaseSalaryByDepartment(List<Employee> employees, String dept, int incSalary) {
		return employees.stream()
                .map(employee -> {
                    if (employee.getDepartment().equals(dept)) {
                        employee.setSalary(employee.getSalary() + incSalary);
                    }
                    return employee;
                })
                .collect(Collectors.toList());
	}

	public static List<Employee> promoteEmployeesBasedOnExperience(List<Employee> employees) {
		Calendar now = Calendar.getInstance();
		int currentYear = now.get(Calendar.YEAR);

		return employees.stream().map(employee -> {
			Calendar joiningCalendar = Calendar.getInstance();
			joiningCalendar.setTime(employee.getJoiningDate());
			int joiningYear = joiningCalendar.get(Calendar.YEAR);

			int yearsOfExperience = currentYear - joiningYear;

			if (yearsOfExperience >= 8) {
				employee.setJobLevel("Senior");
			}
			return employee;
		}).collect(Collectors.toList());}

}
