package emp;

import java.time.LocalDate;
import java.util.Date;

public class Employee {

	private String name;
	private String department;
	private int salary;
	private String gender;
	private Date joiningDate;
	private Date dateOfBirth;
	private String jobLevel;

	public Employee(String name, String department, int salary, String gender, Date joiningDate, Date dateOfBirth,
			String jobLevel) {
		this.name = name;
		this.department = department;
		this.salary = salary;
		this.gender = gender;
		this.joiningDate = joiningDate;
		this.dateOfBirth = dateOfBirth;
		this.jobLevel = jobLevel;

	}
	public String getName() {
		return name;
	}
	public String getDepartment() {
		return department;
	}
	public int getSalary() {
		return salary;
	}
	public String getGender() {
		return gender;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getJobLevel() {
		return jobLevel;
	}
	public void setJobLevel(String jobLevel) {
		this.jobLevel = jobLevel;
	}
	
	@Override
    public String toString() {
        return name + " - " + department + " - " + salary + " - " + jobLevel;
    }
	
}
