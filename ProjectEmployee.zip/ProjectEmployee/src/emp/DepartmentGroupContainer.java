package emp;

import java.util.List;

public class DepartmentGroupContainer {

	
	private String department;
	
	private List<Employee> employees;
	
	
	public DepartmentGroupContainer(String department,List<Employee> employees) {
		this.department = department;
		this.employees  = employees;
	}

	public String getDepartment() {
		return department;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	@Override
    public String toString() {
        return "DepartmentGroupContainer -->" +
                "department='" + department + '\'' +
                ", employees=" + employees ;
    }
	
}
