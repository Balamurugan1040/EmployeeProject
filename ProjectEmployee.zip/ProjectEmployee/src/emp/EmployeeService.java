package emp;

import java.util.Calendar;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class EmployeeService {

	
	
	public void validateEmpAge(Employee employee) throws Exception {

		Calendar joinCalendar = Calendar.getInstance();
		joinCalendar.setTime(employee.getJoiningDate());
		int joiningYear = joinCalendar.get(Calendar.YEAR);

		Calendar dobCalendar = Calendar.getInstance();
		dobCalendar.setTime(employee.getDateOfBirth());
		int dobYear = dobCalendar.get(Calendar.YEAR);

		System.out.println("Joining Year " + joiningYear);
		System.out.println("DOB Year " + dobYear);

		int ageAtJoining = joiningYear - dobYear;
		if (ageAtJoining < 21) {
			throw new Exception("Employee age must be at least 21");
		}
	}

	public void getCountEmpByDept(List<Employee> employees) {
		CompletableFuture.runAsync(() -> {
			EmployeeManagement.countEmployeesByDepartment(employees).forEach(System.out::println);
		}).join();
	}

	public void getGroupEmpByDept(List<Employee> employees) {
		
		CompletableFuture.runAsync(() -> {
            EmployeeManagement.groupEmployeesByDepartment(employees).forEach(System.out::println);
        }).join();
		
	}

	public void getIncrementSalary(List<Employee> employees, String dept, int incSalary) {
		
		CompletableFuture.runAsync(() -> {
            EmployeeManagement.increaseSalaryByDepartment(employees, dept, incSalary).forEach(System.out::println);
        }).join();
		
	}

	public void getPromoteEmploees(List<Employee> employees) {
		CompletableFuture.runAsync(() -> {
            EmployeeManagement.promoteEmployeesBasedOnExperience(employees).forEach(System.out::println);
        }).join();
		
	}

}
