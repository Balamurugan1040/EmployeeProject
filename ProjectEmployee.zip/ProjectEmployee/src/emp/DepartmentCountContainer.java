package emp;


public class DepartmentCountContainer {
	
	private String department;
	private long employeeCount;
	

	public DepartmentCountContainer(String department, long employeeCount) {
		this.department = department;
		this.employeeCount  = employeeCount;
	}
	
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	public long getEmployeeCount() {
		return employeeCount;
	}

	public void setEmployeeCount(long employeeCount) {
		this.employeeCount = employeeCount;
	}
	
	@Override
    public String toString() {
        return "DepartmentCountContainer-->" +
                "department='" + department + '\'' +
                ", employeeCount=" + employeeCount ;
    }
	
}
